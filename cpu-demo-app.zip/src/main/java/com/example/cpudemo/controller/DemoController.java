package com.example.cpudemo.controller;

import com.example.cpudemo.service.CpuIntensiveService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

    private final CpuIntensiveService service;

    public DemoController(CpuIntensiveService service) {
        this.service = service;
    }

    @GetMapping("/cpu")
    public String cpu() {
        service.highCpuTask();
        return "CPU task completed";
    }

    @GetMapping("/io")
    public String io() throws InterruptedException {
        Thread.sleep(2000);
        return "I/O task completed";
    }
}
