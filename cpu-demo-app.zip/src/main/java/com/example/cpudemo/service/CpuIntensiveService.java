package com.example.cpudemo.service;

import org.springframework.stereotype.Service;

@Service
public class CpuIntensiveService {

    public void highCpuTask() {
        long result = 0;
        for (long i = 0; i < 1_000_000_000L; i++) {
            result += Math.sqrt(i);
        }
        System.out.println("Result: " + result);
    }
}
