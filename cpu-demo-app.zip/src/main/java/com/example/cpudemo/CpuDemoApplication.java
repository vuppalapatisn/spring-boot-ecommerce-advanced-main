package com.example.cpudemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpuDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(CpuDemoApplication.class, args);
    }
}
