package com.example.eventcache.listener;

import org.springframework.cache.CacheManager;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Component;

@Component
public class CacheInvalidationListener implements MessageListener {

 private final CacheManager cacheManager;

 public CacheInvalidationListener(CacheManager cacheManager) {
  this.cacheManager = cacheManager;
 }

 @Override
 public void onMessage(Message message, byte[] pattern) {
  String key = new String(message.getBody());
  cacheManager.getCache("users").evict(key);
  System.out.println("Evicted cache key via event: " + key);
 }
}