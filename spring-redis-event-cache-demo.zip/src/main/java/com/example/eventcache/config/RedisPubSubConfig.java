package com.example.eventcache.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;

@Configuration
public class RedisPubSubConfig {
 @Bean
 public ChannelTopic cacheInvalidationTopic() {
  return new ChannelTopic("cache-invalidation");
 }

 @Bean
 public RedisMessageListenerContainer redisContainer(
   RedisConnectionFactory factory,
   com.example.eventcache.listener.CacheInvalidationListener listener,
   ChannelTopic topic) {

  RedisMessageListenerContainer container = new RedisMessageListenerContainer();
  container.setConnectionFactory(factory);
  container.addMessageListener(listener, topic);
  return container;
 }
}