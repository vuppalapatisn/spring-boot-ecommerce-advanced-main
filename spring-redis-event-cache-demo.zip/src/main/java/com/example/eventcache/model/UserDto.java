package com.example.eventcache.model;
public record UserDto(String id, String name) {}