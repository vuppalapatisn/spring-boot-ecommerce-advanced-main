package com.example.eventcache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class EventCacheApplication {
 public static void main(String[] args) {
  SpringApplication.run(EventCacheApplication.class, args);
 }
}