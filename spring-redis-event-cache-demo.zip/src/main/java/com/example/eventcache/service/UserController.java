package com.example.eventcache.service;

import com.example.eventcache.model.UserDto;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {

 private final UserService service;
 private final CacheInvalidationPublisher publisher;

 public UserController(UserService service, CacheInvalidationPublisher publisher) {
  this.service = service;
  this.publisher = publisher;
 }

 @GetMapping("/{id}")
 public UserDto get(@PathVariable String id) {
  return service.getUser(id);
 }

 @PutMapping("/{id}")
 public void update(@PathVariable String id) {
  publisher.publishEviction(id);
 }
}