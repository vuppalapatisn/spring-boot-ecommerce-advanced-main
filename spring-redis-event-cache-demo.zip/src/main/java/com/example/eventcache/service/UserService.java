package com.example.eventcache.service;

import com.example.eventcache.model.UserDto;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class UserService {

 @Cacheable(value = "users", key = "#id", sync = true)
 public UserDto getUser(String id) {
  try { Thread.sleep(1000); } catch (Exception ignored) {}
  return new UserDto(id, "User-" + id);
 }
}