package com.example.eventcache.service;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.stereotype.Service;

@Service
public class CacheInvalidationPublisher {

 private final StringRedisTemplate redisTemplate;
 private final ChannelTopic topic;

 public CacheInvalidationPublisher(StringRedisTemplate redisTemplate, ChannelTopic topic) {
  this.redisTemplate = redisTemplate;
  this.topic = topic;
 }

 public void publishEviction(String key) {
  redisTemplate.convertAndSend(topic.getTopic(), key);
 }
}